# Identidad oficial de Äura

Logo aprobado el 28 de septiembre de 2026. El archivo `approved/aura-wordmark-source.png` es la imagen original elegida; se conserva sin redibujar. Las versiones PNG recortadas preservan ese diseño y su transparencia. Las versiones SVG son trazados de alta fidelidad para ampliación e impresión.

## Uso

- **Fondo claro:** `approved/aura-wordmark-burgundy.png` o `.svg`.
- **Fondo oscuro:** `approved/aura-wordmark-white.png` o `.svg`.
- **Impresora térmica:** `approved/aura-wordmark-black.svg` en negro puro.
- **Favicon/app:** `approved/aura-icon.svg`, monograma secundario inspirado en la Ä del logotipo.

El logo horizontal es la firma principal de la marca. La tienda carga versiones optimizadas desde `public/brand/`. El ERP incorpora el trazado negro en cada SVG de etiqueta de 40 × 40 mm, de modo que el archivo descargado se imprime sin depender de recursos externos.

Los flyers de Instagram están en `flyers/instagram-1080x1350/` y `flyers/captions.csv`; el catálogo utilizado se guardó en `flyers/catalogo-visible-2026-09-28.json`.
